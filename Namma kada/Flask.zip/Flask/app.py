from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configure MySQL connection
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'your_mysql_username'
app.config['MYSQL_PASSWORD'] = 'your_mysql_password'
app.config['MYSQL_DB'] = 'namma_kada_db'  # Create this MySQL database

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_item', methods=['POST'])
def add_item():
    item_name = request.form['item_name']
    item_rate = float(request.form['item_rate'])
    
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO items (name, rate) VALUES (%s, %s)', (item_name, item_rate))
    mysql.connection.commit()
    cur.close()
    
    return 'Item added successfully'

# Rest of the code remains the same...
